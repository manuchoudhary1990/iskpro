<?php
/*
Plugin Name: TV9 Digital
Plugin URI: https://tv9hindi.com
Description: Display TV9 News
Version: 1.0.0
Author: Manu Choudhary
Author URI: https://tv9hindi.com
License: GPL2
*/
define('SECTION_PLUGIN_PATH',   plugin_dir_path(__FILE__));
define('SECTION_PLUGIN_URL_PATH',   plugins_url('', __FILE__));

register_activation_hook( __FILE__, 'my_plugin_activation' );
function my_plugin_activation() {
	global $table_prefix, $wpdb;
	$tv9digitalTable = $table_prefix . 'tv9digital';
	if( $wpdb->get_var( "show tables like '$tv9digitalTable'" ) != $tv9digitalTable ) {

		$sql = "CREATE TABLE `$tv9digitalTable` (";
		$sql .= " `id` int(11) NOT NULL auto_increment, ";
		$sql .= " `title` varchar(500), ";
		$sql .= " `description` varchar(500), ";
		$sql .= " `author` varchar(500), ";
		$sql .= " PRIMARY KEY (`id`) ";
		$sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";
		require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

	}
}

add_action('admin_menu', 'test_plugin_setup_menu');
function test_plugin_setup_menu(){
    add_menu_page( 'TV9 Digital', 'TV9 Digital', 'manage_options', 'tv9-digital', 'tv9_digital_init' );
    add_submenu_page("tv9-digital", "Add New", "Add New", 0, "add-new-tv9", "add_new_tv9digital");
}

function tv9_digital_init(){

	wp_enqueue_style('tv9digital_style1', plugin_dir_url( __FILE__ )."assets/css/jquery.dataTables.min.css");
	wp_enqueue_script( 'tv9digital_script1', plugin_dir_url( __FILE__ ). 'assets/js/jquery.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script('tv9digital_script2', plugin_dir_url( __FILE__ )."assets/js/jquery.dataTables.min.js", array('jquery'), '1.0.1', true);	
	?>

	<div class="wrap">
		<h1 class="wp-heading-inline">TV9 Digital</h1><a href="<?php echo admin_url(); ?>admin.php?page=add-new-tv9" class="page-title-action">Add New</a>
		<style>table th{text-align: left; padding-left: 10px !important;}</style>
		<table id='empTable' class='display dataTable'>
		  <thead>
		    <tr>
		      <th>ID</th>
		      <th>Title</th>
		      <th>Author</th>
		      <th>Action</th>
		    </tr>
		  </thead>
		</table>

		<script type="text/javascript">
			jQuery(document).ready(function(){
			   $('#empTable').DataTable({
			      'processing': true,
			      'serverSide': true,
			      'serverMethod': 'post',
			      'ajax': {
			      	  'type': 'post',
			          'url':'<?php echo SECTION_PLUGIN_URL_PATH; ?>/includes/ajaxfile.php',
			          "data": function ( d ) {
		                d.action = "tbl_pagination";
		            }
			      },
			      'columns': [
			         { data: 'id' },
			         { data: 'title' },
			         { data: 'author' },
			         { data: 'action' },
			      ]
			   });
			
			});

			function deleteFun(intId){
				jQuery.ajax({
		          type:'POST',
		          data:{action:'tv9digital_delete_post_action', postid: intId},
		          url:'<?php echo SECTION_PLUGIN_URL_PATH; ?>/includes/ajaxfile.php',
		          success: function(value) {
		          	
		          	if(value=='success'){
		          		alert('Record Deleted Successfully');
		          		location.reload();
		          	}
		          	
		          }
		        });
			}
		</script>
	</div>
	<?php
	}

	function add_new_tv9digital(){
		global $wpdb;
		$table_name=$wpdb->prefix.'tv9digital';

		if(isset($_POST['post_submit']) && $_POST['post_submit'] == 'Submit'){
			$current_user = wp_get_current_user();
			$result_check = $wpdb->insert(
				$table_name,
				array(
					'title' => $_POST['tv9title'],
					'description' => $_POST['tv9description'],
					'author' => $current_user->user_login
				)
			);
			if($result_check){
			   $lastid = $wpdb->insert_id;
			   wp_redirect(admin_url().'admin.php?page=add-new-tv9&postid='.$lastid);
			   
			}
		}

		if(isset($_POST['update_submit']) && $_POST['update_submit'] == 'Update'){
			$postid = $_GET['postid'];
			$posttitle = $_POST['tv9title'];
			$postdesc = $_POST['tv9description'];
			$result_update = $wpdb->update($table_name, array('title' => $posttitle, 'description' => $postdesc), array( 'id' => $postid ));

			if($result_update){
			   wp_redirect(admin_url().'admin.php?page=add-new-tv9&postid='.$postid);
			   
			}
		}

		if(isset($_GET['postid']) && $_GET['postid'] != ''){
			$post_id = $_GET['postid'];
			$post_result = $wpdb->get_results("SELECT * FROM $table_name WHERE id=$post_id");
		}

		?>
		<script src="<?php echo plugin_dir_url( __FILE__ ).'assets/js/tinymce.min.js'; ?>" referrerpolicy="origin"></script>
		<script>
			tinymce.init({
			selector: "textarea",
			menubar:false,
	    	statusbar: false,
			plugins: [
			"insertdatetime"
			],
			width: 700,
			height: 400
			})
		</script>
		<div class="wrap">
			<form method ="post">
				<?php  ?>
				<p>
					<input type="text" name="tv9title" id="tv9title" placeholder="Title" value="<?php echo ($post_result[0]->title) ? $post_result[0]->title : ''; ?>" required>
				</p>
				<p>
					<textarea name="tv9description" id="tv9description"><?php echo ($post_result[0]->description) ? $post_result[0]->description : ''; ?></textarea>
				</p>
				<p>
				<?php if(isset($_GET['postid']) && $_GET['postid'] != ''){
					echo '<input type="submit" name="update_submit" value="Update">';
				}else{
					echo '<input type="submit" name="post_submit" value="Submit">';
				}
				?>
				</p>
			</form>
		</div>
		
		<?php
	}


