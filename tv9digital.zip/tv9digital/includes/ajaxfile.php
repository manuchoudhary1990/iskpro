<?php
require_once("../../../../wp-load.php");
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length'];
$columnIndex = $_POST['order'][0]['column'];
$columnName = $_POST['columns'][$columnIndex]['data'];
$columnSortOrder = $_POST['order'][0]['dir'];
$searchValue = $_POST['search']['value'];

## Search 
$searchQuery = " ";
if($searchValue != ''){
   $searchQuery = " and (title like '%".$searchValue."%' or 
        description like '%".$searchValue."%' ) ";
}


global $wpdb;
$prefix = $wpdb->prefix;


$strAction = $_POST['action'];


switch ($strAction) {
   case "tv9digital_delete_post_action":

         $intPostId = $_POST['postid'];
         $tv9digitalTable = $table_prefix . 'tv9digital';
         $delete_result = $wpdb->delete( $tv9digitalTable, array( 'id' => $intPostId ) );
         if($delete_result){
            echo "success";
         }
         exit();
         break;

   case "tbl_pagination":
    
         $table_name = $prefix.'tv9digital';
         $mduser_results = $wpdb->get_results("SELECT * FROM $table_name");
         $totalRecords = count($mduser_results);

         $mduser_results = $wpdb->get_results("SELECT * FROM $table_name WHERE 1 $searchQuery");
         $totalRecordwithFilter = count($mduser_results);

         $empRecords = $wpdb->get_results("SELECT * FROM $table_name WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage);

         $data = array();

         foreach ($empRecords as $rows) {
            $data[] = array( 
               "id"=>$rows->id,
               "title"=>$rows->title,
               "author"=>$rows->author,
               "action"=>'<span style="margin-right:10px;"><a href="'.admin_url().'admin.php?page=add-new-tv9&postid='.$rows->id.'">Edit</a></span><a onClick=" deleteFun('.$rows->id.') ;">Delete</a>',
            );
         }

         ## Response
         $response = array(
           "draw" => intval($draw),
           "iTotalRecords" => $totalRecords,
           "iTotalDisplayRecords" => $totalRecordwithFilter,
           "aaData" => $data
         );
         echo json_encode($response);
         exit();

         break;

}
